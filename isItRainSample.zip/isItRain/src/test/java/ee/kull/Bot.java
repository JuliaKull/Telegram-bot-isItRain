package ee.kull;

import ee.kull.service.SendMessageService;
import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.BotApiMethod;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;

import static ee.kull.constant.Const.*;

public class Bot extends TelegramLongPollingBot {


    SendMessageService service = new SendMessageService();


    public void onUpdateReceived(Update update) {
        if(update.hasMessage() && update.getMessage().hasText()){
            switch (update.getMessage().getText()){
                case START:
                        executeMessage(service.sayHelloMessage(update));
                    break;
                case START_PLANNING:
                    executeMessage(service.createPlaningMessage(update));
                    break;
                case FINISH_PLANNING:
                    executeMessage(service.createFinishMessage(update));
            }
        }}

    @Override
    public String getBotUsername() {
        return USERNAME;
    }

    @Override
    public String getBotToken() {
        return TOKEN;
    }

    private <T extends BotApiMethod> void executeMessage(T sendMessage){
        try{
            execute(sendMessage);
        }
        catch (TelegramApiException e){
            e.printStackTrace();
        }
    }
}
