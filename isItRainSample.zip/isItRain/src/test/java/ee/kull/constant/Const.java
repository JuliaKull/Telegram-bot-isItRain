package ee.kull.constant;

public class Const {
public static final String START = "/start";
public static final String START_PLANNING = "Start planing";
public static final String FINISH_PLANNING = "Finish planing";
public static final String SHOW_DEALS = "Show all";

public static final String TOKEN = "5305147279:AAHVbsr05KZtBaroJf7ID6mYfOH9t9w-IaU";

public static final String USERNAME = "IsitRain_bot";
}
