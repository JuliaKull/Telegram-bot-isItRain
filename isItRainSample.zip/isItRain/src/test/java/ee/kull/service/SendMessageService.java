package ee.kull.service;

import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.ReplyKeyboardMarkup;

import static ee.kull.constant.Const.*;
import static java.util.Arrays.asList;

public class SendMessageService {
    private final String HELLO = "Hello";
    private final String PLANNING_MESSAGE = "Add your TODO, then press FINISH";
    private final String FINISH_MESSAGE = "All TODO is added. Press SHOW ALL to see what u add";
    private final String SHOW_MESSAGE = "Wow!You planed a lot!";
    private final ButtonService buttonService = new ButtonService();


    public SendMessage createPlaningMessage(Update update) {
        return createSimpleMessage(update,PLANNING_MESSAGE);
    }

    public SendMessage createFinishMessage(Update update) {
        return createSimpleMessage(update,FINISH_MESSAGE);
    }


    public SendMessage sayHelloMessage(Update update) {
        SendMessage  message = createSimpleMessage(update, HELLO);
        ReplyKeyboardMarkup keyboardMarkup = buttonService.setButtons(buttonService.createButtons(
                asList(START_PLANNING, FINISH_PLANNING,SHOW_DEALS)));
        message.setReplyMarkup(keyboardMarkup);
        return message;
    }

    private SendMessage createSimpleMessage(Update update, String message) {
        SendMessage sendMessage = new SendMessage();
        sendMessage.setChatId(String.valueOf(update.getMessage().getChatId()));
        sendMessage.setText(message);
        return sendMessage;
    }
}
